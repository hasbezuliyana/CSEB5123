 

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Project_Developer List</h1>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Project ID</th>
                <th>Developer ID</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $projectDeveloper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectDeveloper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($projectDeveloper->id); ?></td>
                    <td><?php echo e($projectDeveloper->project_id); ?></td>
                    <td><?php echo e($projectDeveloper->developer_id); ?></td>
                    <td>
                        <a href="<?php echo e(route('project_developer.show', $project_developer->id)); ?>" class="btn btn-info">View</a>
                        <a href="<?php echo e(route('project_developer.edit', $project_developer->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('project_developer.destroy', $project_developer->id)); ?>" method="POST" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\laravelproject\final\resources\views/project_developers/index.blade.php ENDPATH**/ ?>