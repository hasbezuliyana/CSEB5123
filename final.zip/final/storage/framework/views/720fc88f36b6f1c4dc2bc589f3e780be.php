 

<?php $__env->startSection('content2'); ?>
    <div class="container">
        <h1>Manager</h1>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Contact No</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $manager; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($manager->id); ?></td>
                    <td><?php echo e($manager->name); ?></td>
                    <td><?php echo e($manager->contact_no); ?></td>
                    <td>
                        <a href="<?php echo e(route('bus.show', $manager->id)); ?>" class="btn btn-info">View</a>
                        <a href="<?php echo e(route('bus.edit', $manager->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('bus.destroy', $manager->id)); ?>" method="POST" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\laravelproject\final\resources\views/managers/index.blade.php ENDPATH**/ ?>