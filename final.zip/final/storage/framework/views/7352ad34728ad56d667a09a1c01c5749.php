<?php $__env->startSection('content2'); ?>
    <h1>Project: <?php echo e($project->id); ?></h1>
    <p>Project Name: <?php echo e($project->project_name); ?></p>
    <p>System PIC: <?php echo e($project->system_pic); ?></p>
    <p>System Owner: <?php echo e($project->system_owner); ?></p>
    <p>Start Date: <?php echo e($project->start_date); ?></p>
    <p>End Date: <?php echo e($project->end_date); ?></p>
    <p>Duration: <?php echo e($project->duration); ?></p>
    <p>Methodology: <?php echo e($project->methodology); ?></p>
    <p>Platform: <?php echo e($project->platform); ?></p>
    <p>Deployment Type: <?php echo e($project->deployment_type); ?></p>
    <a href="<?php echo e(route('projects.index')); ?>">Back to List</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\laravelproject\final\resources\views/projects/show.blade.php ENDPATH**/ ?>