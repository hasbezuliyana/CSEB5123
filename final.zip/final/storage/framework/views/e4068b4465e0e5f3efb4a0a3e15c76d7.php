 

<?php $__env->startSection('content2'); ?>
    <div class="container">
        <h1>Projects</h1>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Project Name</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($project->id); ?></td>
                <td><?php echo e($project->project_name); ?></td>
                <td>
                    <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-info">View</a>
                    <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\laravelproject\final\resources\views/projects/index.blade.php ENDPATH**/ ?>