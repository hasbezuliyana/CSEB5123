 

<?php $__env->startSection('content2'); ?>
    <div class="container">
        <h1>Business Units</h1>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>PIC Name</th>
                <th>Contact No</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $bu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($bu->id); ?></td>
                    <td><?php echo e($bu->name); ?></td>
                    <td><?php echo e($bu->system_pic); ?></td>
                    <td><?php echo e($bu->contact_no); ?></td>
                    <td>
                        <a href="<?php echo e(route('bus.show', $bu->id)); ?>" class="btn btn-info">View</a>
                        <a href="<?php echo e(route('bus.edit', $bu->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('bus.destroy', $bu->id)); ?>" method="POST" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\laravelproject\final\resources\views/bus/index.blade.php ENDPATH**/ ?>