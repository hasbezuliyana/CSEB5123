<div>
    <!-- Smile, breathe, and go slowly. - Thich Nhat Hanh -->
</div>
