{{-- resources/views/dashboard.blade.php --}}

@extends('layouts.layout')

@section('content2')
                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        {{ __('You are logged in!') }}
                    </div>
@endsection
